using AutoMapper;
using FluentValidation;
using NexusFlow.API.Extensions;
using NexusFlow.API.Filters;
using NexusFlow.API.Middleware;
using NexusFlow.Application.Mappings;
using NexusFlow.Application.Services;
using NexusFlow.Application.Services.Interfaces;
using NexusFlow.Application.Validators.Auth;

var builder = WebApplication.CreateBuilder(args);

// ── Services ──────────────────────────────────────
builder.Services.AddScoped<ValidationFilter>();
builder.Services.AddControllers(options =>
{
    options.Filters.AddService<ValidationFilter>();
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddOpenApi();

builder.Services.AddDatabaseServices(builder.Configuration);
builder.Services.AddJwtAuthentication(builder.Configuration);
builder.Services.AddCorsPolicy(builder.Configuration);
builder.Services.AddRepositories();
builder.Services.AddApplicationServices();
builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddScoped<IAuditLogService, AuditLogService>();

// AutoMapper — scans the Application assembly for all Profile classes
// (ProjectProfile, TaskProfile, CommentProfile, NotificationProfile, UserProfile, AuthProfile)
// NOTE: since AutoMapper v15, every AddAutoMapper overload requires the
// Action<IMapperConfigurationExpression> parameter first — passing just the
// assembly (no cfg lambda) no longer compiles.
builder.Services.AddAutoMapper(cfg => { }, typeof(ProjectProfile).Assembly);

// FluentValidation — scans the Application assembly for all AbstractValidator<T> classes
builder.Services.AddValidatorsFromAssemblyContaining<RegisterRequestDtoValidator>();

// ── Pipeline ──────────────────────────────────────
var app = builder.Build();

app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();
app.UseCors("NexusFlowCors");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();